import React from 'react';

const Loading = () => {
    return (
        <section className="loader-wrapper">
            <div className="loader"></div>
        </section>
    );
};

export default Loading;
