/* global appLocalizer */
import Brand from '../../assets/images/Brand.png';
import BrandSmall from '../../assets/images/Brand-small.png';
import React, { useEffect, JSX } from 'react';
import { __ } from '@wordpress/i18n';

// Services
import { getTemplateData } from '../../services/templateService';
// Utils
import {
    getAvailableSettings,
    getSettingById,
    SettingContent,
    Support,
    AdminForm,
    Banner,
    Tabs,
    useModules,
    SettingProvider,
    useSetting,
    type SettingContextType,
} from 'zyra';
import ShowPopup from '../Popup/Popup';
import { useLocation, Link } from 'react-router-dom';

// Types
type SettingItem = Record<string, any>;

interface SettingsProps {
    id: string;
}

interface Products {
    title: string;
    description: string;
}

const supportLink = [
    {
        title: __('Get in touch with Support', 'catalogx'),
        icon: 'mail',
        description: __(
            'Reach out to the support team for assistance or guidance.',
            'catalogx'
        ),
        link: 'https://catalogx.com/support/?utm_source=wpadmin&utm_medium=pluginsettings&utm_campaign=catalogx',
    },
    {
        title: __('Explore Documentation', 'catalogx'),
        icon: 'submission-message',
        description: __('Understand the plugin and its settings.', 'catalogx'),
        link: 'https://catalogx.com/docs/?utm_source=wpadmin&utm_medium=pluginsettings&utm_campaign=catalogx',
    },
    {
        title: __('Contribute Here', 'catalogx'),
        icon: 'support',
        description: __('To participate in product enhancement.', 'catalogx'),
        link: 'https://github.com/multivendorx/catalogx/issues',
    },
];

const products: Products[] = [
    {
        title: __('Advanced Enquiries', 'catalogx'),
        description: __('Rich customer-admin messaging system', 'catalogx'),
    },
    {
        title: __('Dynamic Pricing', 'catalogx'),
        description: __('Automated multi-tier price rules', 'catalogx'),
    },
    {
        title: __('Wholesale Sales', 'catalogx'),
        description: __('B2B ordering with bulk discounts', 'catalogx'),
    },
    {
        title: __('Custom Quotes', 'catalogx'),
        description: __('Speed up sales with personalized quotes.', 'catalogx'),
    },
];

const faqs = [
    {
        question:
            'How do I resolve a timeout error when WordPress connects with Moodle?',
        answer: 'When encountering a timeout error during WordPress-Moodle communication, adjust timeout settings in your server configuration to accommodate longer communication durations.',
        open: true,
    },
    {
        question:
            'How can I troubleshoot connection errors during Test connection?',
        answer: 'Navigate to the "Log" menu, where you can use the "Log" feature to troubleshoot connectivity issues between your store and Moodle. This tool helps identify necessary changes for resolution.',
        open: false,
    },
    {
        question: "Why aren't my customers receiving enrollment emails?",
        answer: 'Install a plugin like Email Log to check if New Enrollment emails are logged. If logged, your email functionality is working fine; if not, contact your email server administrator for assistance.',
        open: false,
    },
    {
        question: 'Can I set course expiration dates using MooWoodle?',
        answer: 'Course-related functionalities, including setting expiration dates, are managed within Moodle itself; MooWoodle does not control these aspects.',
        open: false,
    },
];

const Settings: React.FC<SettingsProps> = () => {
    const settingsArray: SettingItem[] = getAvailableSettings(
        getTemplateData(),
        []
    );
    const location = new URLSearchParams(useLocation().hash.substring(1));

    const getBanner = () => {
        return (
            <Banner
                products={products}
                isPro={false}
                proUrl={appLocalizer.pro_url}
                tag="Why Premium"
                buttonText="View Pricing"
                bgCode="#852aff" // backgroud color
                textCode="#fff" // text code
                btnCode="#fff" // button color
                btnBgCode="#e35047" // button backgroud color
            />
        );
    };
    // Render the dynamic form
    const GetForm = (currentTab: string | null): JSX.Element | null => {
        const {
            setting,
            settingName,
            setSetting,
            updateSetting,
        }: SettingContextType = useSetting();
        const { modules } = useModules();

        if (!currentTab) return null;
        const settingModal = getSettingById(settingsArray as any, currentTab);

        // Ensure settings context is initialized
        if (settingName !== currentTab) {
            setSetting(
                currentTab,
                appLocalizer.settings_databases_value[currentTab] || {}
            );
        }

        // eslint-disable-next-line react-hooks/rules-of-hooks
        useEffect(() => {
            if (settingName === currentTab) {
                appLocalizer.settings_databases_value[settingName] = setting;
            }
        }, [setting, settingName, currentTab]);

        // Special component
        if (currentTab === 'faq') {
            return (
                <Support
                    title="Thank you for using CatalogX"
                    subTitle="We want to help you enjoy a wonderful experience with all of our products."
                    // url="https://www.youtube.com/embed/cgfeZH5z2dM?si=3zjG13RDOSiX2m1b"
                    faqData={faqs}
                />
            );
        }

        return (
            <>
                {settingName === currentTab ? (
                    <AdminForm
                        settings={settingModal as SettingContent}
                        proSetting={appLocalizer.settings_databases_value}
                        setting={setting}
                        updateSetting={updateSetting}
                        appLocalizer={appLocalizer}
                        modules={modules}
                        Popup={ShowPopup}
                    />
                ) : (
                    // <>Hii There</>
                    <>Loading...</>
                )}
            </>
        );
    };

    return (
        <SettingProvider>
            <Tabs
                tabData={settingsArray as any}
                currentTab={location.get('subtab') as string}
                getForm={GetForm}
                BannerSection={getBanner}
                prepareUrl={(subTab: string) =>
                    `?page=catalogx#&tab=settings&subtab=${subTab}`
                }
                appLocalizer={appLocalizer}
                brandImg={Brand}
                smallbrandImg={BrandSmall}
                supprot={supportLink}
                Link={Link}
            />
        </SettingProvider>
    );
};

export default Settings;
