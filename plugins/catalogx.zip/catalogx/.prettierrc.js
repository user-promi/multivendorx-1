// This file is used to configure Prettier, a .js, .jsx, .ts, .tsx code formatter.

const defaultConfig = require('@wordpress/prettier-config');

module.exports = {
    ...defaultConfig,
    useTabs: false,
};
