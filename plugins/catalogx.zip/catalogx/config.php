<?php
/**
 * CatalogX config file.
 *
 * @package CatalogX
 */

define( 'CATALOGX_PLUGIN_VERSION', '6.0.5' );

define( 'CATALOGX_PRO_SHOP_URL', 'https://catalogx.com/pricing/?utm_source=wpadmin&utm_medium=pluginsettings&utm_campaign=catalogx' );
